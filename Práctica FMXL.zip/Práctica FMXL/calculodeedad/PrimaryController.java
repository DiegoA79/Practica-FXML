package com.mycompany.calculodeedad;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class PrimaryController {

    @FXML
    private TextField txtFecha;

    @FXML
    private Label lblResultado;

    @FXML
    private void handleCalcular() {
        try {
            String textoFecha = txtFecha.getText().trim();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            
            LocalDate fechaNacimiento = LocalDate.parse(textoFecha, formatter);
            LocalDate fechaActual = LocalDate.now();

            Period periodo = Period.between(fechaNacimiento, fechaActual);
            int años = periodo.getYears();
            int meses = periodo.getMonths();

            lblResultado.setText("Tiene " + años + " años con " + meses + " meses");
            
        } catch (Exception e) {
            lblResultado.setText("Error en el formato (use dd/MM/yyyy)");
        }
    }

    @FXML
    private void handleLimpiar() {
        txtFecha.clear();
        lblResultado.setText("Tiene 0 años con 0 meses");
        txtFecha.requestFocus();
    }
}